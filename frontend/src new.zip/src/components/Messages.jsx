


import React from 'react';
import Message from './Message';
import useGetMessages from '../hooks/useGetMessages';
import { useSelector } from 'react-redux';
import useGetRealTimeMessage from '../hooks/useGetRealTimeMessage';

const Messages = () => {
  useGetMessages();
  useGetRealTimeMessage();

  const { messages } = useSelector((store) => store.message);
  const { authUser, selectedUser } = useSelector((store) => store.user);

  if (!messages || !authUser || !selectedUser) return null;

  // ✅ Filter only those messages between authUser and selectedUser
  const filteredMessages = messages.filter(
    (msg) =>
      (msg.senderId === authUser._id && msg.receiverId === selectedUser._id) ||
      (msg.senderId === selectedUser._id && msg.receiverId === authUser._id)
  );

  return (
    <div className="px-4 flex-1 overflow-auto">
      {filteredMessages.map((message) => (
        <Message key={message._id} message={message} />
      ))}
    </div>
  );
};

export default Messages;
























//last
// import React from 'react'
// import Message from './Message'
// import useGetMessages from '../hooks/useGetMessages';
// import { useSelector } from "react-redux";
// import useGetRealTimeMessage from '../hooks/useGetRealTimeMessage';

// const Messages = () => {
//     useGetMessages();
//     useGetRealTimeMessage();
//     const { messages } = useSelector(store => store.message);
//     return (
//         <div className='px-4 flex-1 overflow-auto'>
//             {
//                messages && messages?.map((message) => {
//                     return (
//                         <Message key={message._id} message={message} />
//                     )
//                 })
              
//             }

//         </div>


//     )
// }

// export default Messages