

import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { setMessages } from "../redux/messageSlice";

const useGetRealTimeMessage = () => {
  const { socket } = useSelector(store => store.socket);
  const { messages } = useSelector(store => store.message);
  const { authUser, selectedUser } = useSelector(store => store.user);
  const dispatch = useDispatch();

  useEffect(() => {
    const handleNewMessage = (newMessage) => {
      // ✅ Only show the message if it's from/to the currently open user
      const from = newMessage.senderId;
      const to = newMessage.receiverId;
      const selectedId = selectedUser?._id;

      const isRelevant =
        (from === selectedId && to === authUser._id) ||
        (from === authUser._id && to === selectedId);

      if (isRelevant) {
        const safeMessages = Array.isArray(messages) ? messages : [];
        dispatch(setMessages([...safeMessages, newMessage]));
      }
    };

    socket?.on("newMessage", handleNewMessage);

    return () => socket?.off("newMessage", handleNewMessage);
  }, [socket, messages, dispatch, selectedUser, authUser]);
};

export default useGetRealTimeMessage;










// import { useEffect } from "react";
// import { useDispatch, useSelector } from "react-redux"

// import { setMessages } from "../redux/messageSlice";

// const useGetRealTimeMessage = () => {
//     const {socket} = useSelector(store=>store.socket);
//     const {messages} = useSelector(store=>store.message);
//     const { authUser, selectedUser } = useSelector(store => store.user);
//     const dispatch =useDispatch();

// //     useEffect(()=>{
// //         socket?.on("newMessage", (newMessage)=>{
// //             dispatch(setMessages([...messages, newMessage]));
// //         });
// //         return () => socket?.off("newMessage");
// //     },[setMessages,messages]);


// // };

//     useEffect(() => {
//         const handleNewMessage = (newMessage) => {
//             const safeMessages = Array.isArray(messages) ? messages : [];
//             dispatch(setMessages([...safeMessages, newMessage]));
//         };

//         socket?.on("newMessage", handleNewMessage);

//         return () => socket?.off("newMessage", handleNewMessage);
//     }, [socket, messages, dispatch]);
// };


// export default useGetRealTimeMessage;




