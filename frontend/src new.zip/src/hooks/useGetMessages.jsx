import React ,{useEffect} from 'react'
import axios from "axios";
import { useSelector,useDispatch } from 'react-redux';
import { setMessages, setCurrentConversationId } from '../redux/messageSlice';




const useGetMessages = () => {
    const {selectedUser} = useSelector(store=>store.user);
    const dispatch = useDispatch();

    useEffect(()=>{
        const fetchMessages= async ()=>{



             // ✅ IMPORTANT: Clear messages when selectedUser changes
            dispatch(setMessages(null)); // or setMessages([]) if you prefer an empty array

            if (!selectedUser?._id) { // Only fetch if a user is selected
                return;
            }



            try{
                axios.defaults.withCredentials=true;
                const res= await axios.get(`http://localhost:8080/api/v1/message/${selectedUser?._id}`);
                console.log(res);
                dispatch(setMessages(res.data))
            }catch(error){
                console.log(error);
            }
        };
        fetchMessages();
    },[selectedUser?._id, dispatch]);
}

export default useGetMessages;